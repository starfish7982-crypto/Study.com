import weka.classifiers.Classifier;
import weka.classifiers.trees.RandomForest;
import weka.core.*;
import weka.core.converters.ConverterUtils.DataSource;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;

public class Main {

    // Define a simple structure for a survey question
    static class Question {
        String text;
        String[] options;

        Question(String text, String[] options) {
            this.text = text;
            this.options = options;
        }
    }

    // Append user data to a CSV file
    public static void appendToCSV(String fileName, String data) {
        try {
            Path path = Paths.get(fileName);
            if (!Files.exists(path)) {
                Files.createFile(path);
            }
            Files.write(path, data.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    // Get and validate user choice input
    public static String askChoice(Scanner scanner, String[] options) {
        while (true) {
            String input = scanner.next().trim();
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= options.length)
                    return options[choice - 1];
            } catch (NumberFormatException ignored) {
            }
            System.out.print("Invalid input. Try again: ");
        }
    }

    public static void main(String[] args) throws Exception {
        // Load ARFF data file
        DataSource dataSource = new DataSource("survey.arff");
        Instances data = dataSource.getDataSet();
        data.setClassIndex(data.numAttributes() - 1);

        // Train a RandomForest classifier
        Classifier classifier = new RandomForest();
        classifier.buildClassifier(data);

        // Mapping of party names to CSV file paths
        Map<String, String> partyToFile = Map.of(
                "Democrat", "./csv/democrat.csv",
                "Republican", "./csv/republican.csv",
                "Libertarian", "./csv/libertarian.csv",
                "Green", "./csv/green.csv");

        // Store user responses
        StringBuilder userAnswers = new StringBuilder();

        // Copy attribute list (except class) from ARFF file
        ArrayList<Attribute> attributes = new ArrayList<>();
        for (int i = 0; i < data.numAttributes() - 1; i++) {
            attributes.add(data.attribute(i));
        }

        // Prepare class attribute values (e.g., democrat, republican...)
        Attribute classAttr = data.attribute(data.classIndex());
        ArrayList<String> classValues = new ArrayList<>();
        Enumeration<Object> values = classAttr.enumerateValues();
        while (values.hasMoreElements()) {
            classValues.add((String) values.nextElement());
        }
        Attribute classAttribute = new Attribute("party", classValues);
        attributes.add(classAttribute);// Add class to attributes

        // Create a new Instances object for one user input
        Instances userInputInstances = new Instances("UserInput", attributes, 1);
        userInputInstances.setClassIndex(userInputInstances.numAttributes() - 1);
        Instance userInput = new DenseInstance(userInputInstances.numAttributes());
        userInput.setDataset(userInputInstances);

        Question[] questions = new Question[] {
                new Question("Do you support LGBTQ+ rights?", new String[] { "yes", "no" }),
                new Question("Should the government act on climate change?", new String[] { "yes", "no" }),
                new Question("Do you support gun control laws?", new String[] { "yes", "no" }),
                new Question("Should abortion be legal?", new String[] { "yes", "no" }),
                new Question("Should immigration laws be stricter?", new String[] { "yes", "no" }),
                new Question("Should U.S. increase military spending?", new String[] { "yes", "no" }),
                new Question("Cut welfare programs?", new String[] { "yes", "no" }),
                new Question("Build a border wall?", new String[] { "yes", "no" }),
                new Question("Reduce military budget?", new String[] { "yes", "no" }),
                new Question("Legalize marijuana?", new String[] { "yes", "no" }),
                new Question("Raise minimum wage?", new String[] { "yes", "no" }),
                new Question("Promote sustainable agriculture?", new String[] { "yes", "no" }),
                new Question("Reduce taxes, limit gov spending?", new String[] { "yes", "no" }),
                new Question("End foreign interventions?", new String[] { "yes", "no" }),
                new Question("Eliminate Federal Reserve?", new String[] { "yes", "no" }),
                new Question("Property rights over gov control?", new String[] { "yes", "no" })
        };

        // Start the survey
        Scanner scanner = new Scanner(System.in);
        String predictedParty = null;
        double[] probabilities = new double[0];

        for (int i = 0; i < questions.length; i++) {
            System.out.printf("\n Question %d of %d\n%s\n", i + 1, questions.length, questions[i].text);
            for (int j = 0; j < questions[i].options.length; j++){
                System.out.printf("%d. %s\n", j + 1, questions[i].options[j]);
            }
            System.out.print("[Answer](type 1 or 2): ");

            String answer = askChoice(scanner, questions[i].options); // Get answer
            userAnswers.append(answer).append(", ");
            userInput.setValue(attributes.get(i), answer);// Set answer to instance

            // Make prediction after each question
            probabilities = classifier.distributionForInstance(userInput);
            int prediction = (int) classifier.classifyInstance(userInput);
            predictedParty = classAttribute.value(prediction);

            // Show prediction result
            System.out.printf("Predicted: %s (%.2f%%)\n", predictedParty, probabilities[prediction] * 100);
        }

        // Final question: party identification
        Question finalQ = new Question("Which party do you identify with?",new String[] { "Democrat", "Republican", "Green", "Libertarian" });
        System.out.println("\nFinal Question\n" + finalQ.text);
        for (int i = 0; i < finalQ.options.length; i++) {
            System.out.printf("%d. %s\n", i + 1, finalQ.options[i]);
        }
        System.out.print("[Answer](type 1-4):");

        String userParty = askChoice(scanner, finalQ.options);
        userAnswers.append(userParty).append("\n");

        // Save user responses to CSV file based on selected party
        appendToCSV(partyToFile.get(userParty), userAnswers.toString());

        // Show result comparison
        if (userParty.equalsIgnoreCase(predictedParty)) {
            System.out.println("\n✅ Thank you! Your answer matches our prediction.");
        } else {
            System.out.println("\n⚠️ Prediction doesn't match your answer.");
        }

        // Warn if model confidence is low
        if (probabilities[classValues.indexOf(predictedParty)] < 0.8) {
            System.out.printf("(Low confidence: %.2f%%)\n", probabilities[classValues.indexOf(predictedParty)] * 100);
        }
    }

}
